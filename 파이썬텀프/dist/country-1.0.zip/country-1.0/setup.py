from distutils.core import setup

setup(name='country',
    version='1.0',
    py_modules=['country_ui', 'gmail', 'internetcountry','launcher','mysmtplib','xmlcountry'],
   ) 
